﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 마영준_공학용계산기만들기
{
    public partial class 마영준계산기 : Form
    {
        double num1, num2;
        string buff = "";
        string output = "";
        char oper;
        double result;

        public 마영준계산기()
        {
            InitializeComponent();
        }

        // 숫자
        private void Bt_num_Click(object sender, MouseEventArgs e)
        {
            Button btn = (Button)sender;
            buff += btn.Text;
            output += btn.Text;
            textBox1.Text = output;
        }

        // 연산자
        private void Bt_oper_Click(object sender, MouseEventArgs e)
        {
            Button btn = (Button)sender;
            num1 = Convert.ToSingle(buff); // 3
            buff = "";                     // 0
            output += btn.Text;            // 3 + 
            textBox1.Text = output;        // 3 + 
            oper = btn.Text[0];            // +
        }

        // 클리어
        private void Bt_clear_Click(object sender, MouseEventArgs e)
        {
            textBox1.Text = "";
            num1 = 0;
            num2 = 0;
            buff = "";
            output = "";
            result = 0.0;
        }



        // 계산
        private void Bt_calc_Click(object sender, MouseEventArgs e)
        {
            Button btn = (Button)sender;      // btn에는 = 가 저장됨
            num2 = Convert.ToInt32(buff);    // num2 =  8  buff(8)

            switch (oper)  // +
            {
                case '+': result = num1 + num2; break;  // result=11
                case '-': result = num1 - num2; break;
                case '*': result = num1 * num2; break;
                case '/':
                    if (num2 == 0)
                    {
                        textBox1.Text = "0으로 나눌수 없음";
                        return;
                    }
                    result = num1 / num2; break;
            }
            //  btn에는 = 가 저장됨
            output += btn.Text + result.ToString();   //  =  결과값 
            textBox1.Text = output;
            // num2=8이고 result=3+8 btn(=)11,  
            // output=3+8 btn(=)11,Textbox1=3+8=11

        }

        private void 마영준계산기_Load(object sender, EventArgs e)
        {
            textBox1.Text = output;
        }
    }
}
